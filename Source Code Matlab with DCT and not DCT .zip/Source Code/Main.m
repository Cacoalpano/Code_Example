%Kich ban nen anh co DCT
X= standard('shangrila.bmp',1);
%Kich ban nen khong co DCT
X=Not_DCT('shangrila.bmp'); %Encode does not DCT, too late , wait about 20 min, done
